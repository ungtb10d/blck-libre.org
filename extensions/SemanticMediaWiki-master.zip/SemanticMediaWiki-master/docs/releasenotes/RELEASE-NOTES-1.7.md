Released on January 1, 2012.

* Added native "internal objects" that can be set using #subobject.
* Added support for selecting a default graph when using RDF stores,
  configuration called $smwgSparqlDefaultGraph
* Use of native MediaWiki sortable tables for the table formats.
* Added value distribution functionality that can be used by result formats.
* Added validation and manipulation of the 'format' parameter using Validator.
* Added 'class' parameter to the 'table' format, which allows setting the CSS
  class.
* Added automatically-generated CSS classes for rows and cells in 'table' format.
* Added alpha version of native SMW Ask API with modules 'ask' and 'askargs'.
* Added alpha version of a new ask query interface: Special:QueryCreator.
* Added setting to choose which optional special properties are enabled ($smwgPageSpecialProperties).
* Added creation date special property (disabled by default) (bug 32165).
* Added support for altitudes in geographic coordinates (bug 32698).
* Added definitions for missing params (sort, order, searchlabel) to the base query printer.
* Added automatic invocation of the SMW_setup maintenance script when running
  update.php (for MW >= 1.19).
* Added support for the Page Schemas extension.
* Removed defunct "SMWLight" files.
* Fixed separator and filename parameters for the DSV format.
* Fixed display of properties of type URL (bug 30912).
* Fixed hide query functionality on Special:Ask (bug 30768).
* Fixed display of internal SMW helper constants in certain queries (bug 30969).
* Fixed some issues with the category result format (including bug 30761).
* Fixed email validation issue (bug 32295).
* Fixed incorrect handling of sort and order parameters on Special:Ask (bug 32706).
* Fixed display of images to old behavior after a recent regression.
* Fixed fatal error in the concept cache maintenance script (bug 32592).
* Fixed factbox links to Special:SearchByProperty containing numerical numbers for
  wikis in languages with the comma as decimal separator instead of a dot.
* Fixed the "hide incoming properties" link on Special:Browse.
* Fixed several more issues not listed here.
* Dropped compatibility with MediaWiki 1.15.x (and earlier).
* Dropped compatibility with old-style (SMW < 1.6) query printers.
* Full compatibility with MediaWiki 1.18 and foreward-compatibility with 1.19.

== SMW 1.7.0.2 ==

Released on January 16, 2012.

* Fixed creation of concept cache and display of matching objects on concept pages (bug 32592, 32718).
* Fixed fatal error occurring for some invalid property definitions (bug 33652).
* Fixed error in RSS when using creator or date parameters (bug 33721).
* Fixed incorrect offset of export formats (bug 33726).

== SMW 1.7.0.1 ==

Released on January 9, 2012.

* Fixed bug in "further results" links causing the main column to be displayed twice on Special:Ask (bug 33473).
* Fixed incorrect case-sensitivity of the format parameter (bug 31138).
* Fixed internationalization of magic words.
* Fixed offset and limit value in further results links (bug 33575).


# Semantic MediaWiki 2.1.1

Released on March 2nd, 2015.

## Bug fixes

* #861 Fixed owl property export declaration
* #863 Fixed missing interwiki encoding for the RDF export
* #864 Fixed empty searchlabel raw wikitext display for a QueryResultPrinter with limit=0

<?php

/**
 * This script will be forwarded to rebuildConceptCache.php.
 *
 * @deprecated 1.9.2 This maintenance script has been deprecated, please use
 * rebuildConceptCache.php instead.
 */
require_once ( 'rebuildConceptCache.php' );

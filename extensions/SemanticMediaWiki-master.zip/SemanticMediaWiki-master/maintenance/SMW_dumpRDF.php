<?php

/**
 * This script will be forwarded to dumpRDF.php.
 *
 * @deprecated 2.0 This maintenance script has been deprecated, please use
 * dumpRDF.php instead.
 */
require_once ( 'dumpRDF.php' );

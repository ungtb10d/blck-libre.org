<?php

/**
 * This script will be forwarded to setupStore.php.
 *
 * @deprecated 2.0 This maintenance script has been deprecated, please use
 * setupStore.php instead.
 */
require_once ( 'setupStore.php' );

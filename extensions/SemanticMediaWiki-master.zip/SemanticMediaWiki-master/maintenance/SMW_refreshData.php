<?php

/**
 * This script will be forwarded to rebuildData.php.
 *
 * @deprecated 1.9.2 This maintenance script has been deprecated, please use
 * rebuildData.php instead.
 */
require_once ( 'rebuildData.php' );

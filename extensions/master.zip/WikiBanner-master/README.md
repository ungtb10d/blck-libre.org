WikiBanner
==========

Adds an easy system for adding and configuring wiki banners on MediaWiki powered websites from the LocalSettings.php file.

Installation instructions can be found at http://www.mediawiki.org/wiki/Extension:WikiBanner
